# Tutorial de instalacao

Este guia instala o pacote-fonte da extensao e explica o que ajustar no painel.

## 1. Antes de tudo

Voce precisa ter:

- Pterodactyl Panel funcionando
- Blueprint ja instalado no painel
- acesso root ou sudo no host do painel
- `php`, `artisan`, `rsync`, `ssh` e `zip` funcionando no sistema
- worker de fila do Laravel ativo

O Blueprint continua com framework ativo e documentacao publica, e o ecossistema oficial indica que extensoes sao gerenciadas pelo proprio Blueprint. O repositorio do framework tambem descreve que o patch adiciona backend Laravel, frontend e CLI ao Panel. citeturn668281view2

## 2. Fazer backup

Antes de copiar qualquer coisa:

```bash
cd /var/www/pterodactyl
cp -a /var/www/pterodactyl /var/www/pterodactyl.backup.$(date +%F-%H%M%S)
php artisan optimize:clear
```

## 3. Copiar a extensao

Extraia o zip e copie a pasta da extensao para um diretorio de trabalho temporario.

Exemplo:

```bash
mkdir -p /root/server-migrator
cd /root/server-migrator
unzip server-migrator-blueprint-source.zip
```

## 4. Aplicar os arquivos no painel

Este pacote foi entregue como **codigo-fonte organizado**, entao a instalacao depende de como seu Blueprint atual carrega extensoes locais.

### Opcao A: voce ja tem um padrao de extensoes locais

Se sua instalacao usa uma pasta dedicada para extensoes, copie a estrutura para a pasta esperada pelo seu Blueprint.

### Opcao B: voce vai integrar manualmente

Copie os arquivos respeitando a estrutura:

- `routes/web.php`
- `resources/views/admin/server-migrator.blade.php`
- `app/Http/Controllers/Admin/ServerMigratorController.php`
- `app/Jobs/MigrateServerJob.php`
- `app/Requests/MigrateServerRequest.php`
- `app/Services/ServerMigrationService.php`

## 5. Ajustar namespace/autoload se necessario

Se seu Blueprint exigir registro explicito, adicione o namespace da extensao conforme o padrao da sua release.

Namespace usado aqui:

```php
ServerMigrator\\
```

## 6. Ligar os metodos reais do painel

Edite o arquivo abaixo:

```bash
nano /caminho/da/extensao/app/Services/ServerMigrationService.php
```

Substitua os placeholders:

- `sendPowerSignal()`
- `syncServerWithNode()`

Voce deve conectar esses metodos aos services ou endpoints reais da sua versao do Pterodactyl.

## 7. Garantir SSH entre o host do painel e os nodes

No host do painel:

```bash
ssh-keygen -t ed25519
ssh-copy-id root@IP_DO_NODE_DESTINO
ssh root@IP_DO_NODE_DESTINO 'echo ok'
```

Repita para cada node destino que vai receber migracoes.

## 8. Garantir rsync nos dois lados

No host do painel e em cada node:

```bash
apt update
apt install -y rsync
```

## 9. Limpar cache e recarregar o painel

Dentro da pasta do painel:

```bash
cd /var/www/pterodactyl
php artisan optimize:clear
php artisan view:clear
php artisan config:clear
php artisan route:clear
```

Se sua stack usar frontend/build adicional no Blueprint, rode tambem os comandos recomendados pela sua release.

## 10. Reiniciar fila e PHP

Exemplos comuns:

```bash
systemctl restart redis
systemctl restart pteroq
systemctl restart php8.2-fpm
systemctl restart nginx
```

Ajuste os nomes dos servicos conforme sua distro.

## 11. Como usar

1. abra o painel admin
2. acesse a pagina da extensao ou rota configurada
3. selecione o servidor
4. selecione o node destino
5. selecione uma allocation livre do node destino
6. clique em **Migrar**
7. acompanhe os logs do Laravel e da fila

## 12. Onde a migracao mexe

Fluxo atual do codigo:

1. para o servidor
2. cria a pasta no node destino
3. roda `rsync`
4. atualiza `node_id` e `allocation_id`
5. faz sync placeholder
6. inicia o servidor no destino

## 13. Como acompanhar erros

Logs do Laravel:

```bash
cd /var/www/pterodactyl
 tail -f storage/logs/laravel.log
```

Fila:

```bash
journalctl -u pteroq -f
```

## 14. Pontos que voce deve validar antes de producao

- allocation escolhida realmente pertence ao node destino
- mesma egg/imagem/docker no destino
- disco suficiente no node novo
- o servidor desliga limpo antes do `rsync`
- rollback manual pronto caso algo falhe

## 15. Recomendacao honesta

Para producao, eu ainda faria estas melhorias antes de confiar totalmente:

- rollback automatico
- health check apos subir no node novo
- lock de migracao por servidor
- barra de progresso ou status
- suporte a backup/restore como fallback

## 16. Se quiser transformar isso em pacote mais proximo do instalavel

O proximo passo ideal e adaptar este source package para o formato exato da sua release do Blueprint e do seu painel.

O ecossistema atual do Blueprint continua ativo, com guias de instalacao e gerencia de extensoes, inclusive pagina de administracao para extensoes. citeturn902004search8turn902004search14turn668281view2
