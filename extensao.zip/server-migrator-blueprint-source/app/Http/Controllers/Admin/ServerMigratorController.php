<?php

namespace ServerMigrator\Http\Controllers\Admin;

use Illuminate\Http\RedirectResponse;
use Illuminate\Routing\Controller;
use Illuminate\View\View;
use Pterodactyl\Models\Allocation;
use Pterodactyl\Models\Node;
use Pterodactyl\Models\Server;
use ServerMigrator\Jobs\MigrateServerJob;
use ServerMigrator\Requests\MigrateServerRequest;

class ServerMigratorController extends Controller
{
    public function index(): View
    {
        return view('admin.server-migrator', [
            'servers' => Server::query()->orderByDesc('id')->limit(100)->get(),
            'nodes' => Node::query()->orderBy('name')->get(),
            'allocations' => Allocation::query()
                ->whereNull('server_id')
                ->orderBy('node_id')
                ->orderBy('port')
                ->limit(500)
                ->get(),
        ]);
    }

    public function migrate(MigrateServerRequest $request): RedirectResponse
    {
        $server = Server::query()->findOrFail($request->integer('server_id'));

        MigrateServerJob::dispatch(
            $server->id,
            $request->integer('target_node_id'),
            $request->integer('target_allocation_id')
        );

        return redirect()
            ->route('admin.server-migrator.index')
            ->with('success', 'Migração enviada para a fila. Acompanhe os logs e a queue worker.');
    }
}
