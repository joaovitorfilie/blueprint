<?php

namespace ServerMigrator\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use ServerMigrator\Services\ServerMigrationService;

class MigrateServerJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $timeout = 3600;

    public function __construct(
        public int $serverId,
        public int $targetNodeId,
        public int $targetAllocationId,
    ) {
    }

    public function handle(ServerMigrationService $service): void
    {
        $service->migrate(
            serverId: $this->serverId,
            targetNodeId: $this->targetNodeId,
            targetAllocationId: $this->targetAllocationId,
        );
    }
}
