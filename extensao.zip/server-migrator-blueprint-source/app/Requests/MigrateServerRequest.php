<?php

namespace ServerMigrator\Requests;

use Illuminate\Foundation\Http\FormRequest;

class MigrateServerRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    public function rules(): array
    {
        return [
            'server_id' => ['required', 'integer'],
            'target_node_id' => ['required', 'integer'],
            'target_allocation_id' => ['required', 'integer'],
        ];
    }

    public function messages(): array
    {
        return [
            'server_id.required' => 'Selecione um servidor.',
            'target_node_id.required' => 'Selecione o node de destino.',
            'target_allocation_id.required' => 'Selecione a allocation de destino.',
        ];
    }
}
