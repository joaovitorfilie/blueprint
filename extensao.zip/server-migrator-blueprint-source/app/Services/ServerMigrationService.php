<?php

namespace ServerMigrator\Services;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Pterodactyl\Models\Allocation;
use Pterodactyl\Models\Node;
use Pterodactyl\Models\Server;
use RuntimeException;

class ServerMigrationService
{
    public function migrate(int $serverId, int $targetNodeId, int $targetAllocationId): void
    {
        $server = Server::query()->findOrFail($serverId);
        $sourceNode = Node::query()->findOrFail((int) $server->node_id);
        $targetNode = Node::query()->findOrFail($targetNodeId);
        $targetAllocation = Allocation::query()->findOrFail($targetAllocationId);

        if ((int) $targetAllocation->node_id !== (int) $targetNode->id) {
            throw new RuntimeException('A allocation selecionada nao pertence ao node de destino.');
        }

        if ((int) $server->node_id === (int) $targetNodeId) {
            throw new RuntimeException('O servidor ja esta neste node.');
        }

        $uuid = $server->uuid;
        $sourcePath = "/var/lib/pterodactyl/volumes/{$uuid}";
        $targetPath = "/var/lib/pterodactyl/volumes/{$uuid}";

        Log::info('server-migrator: starting migration', [
            'server_id' => $server->id,
            'server_uuid' => $uuid,
            'source_node_id' => $sourceNode->id,
            'target_node_id' => $targetNode->id,
            'target_allocation_id' => $targetAllocation->id,
        ]);

        // 1) Stop the server.
        $this->sendPowerSignal($server, 'stop');
        sleep(8);

        // 2) Prepare destination path.
        $this->runSsh(
            $targetNode,
            'mkdir -p ' . escapeshellarg($targetPath) .
            ' && chown -R www-data:www-data ' . escapeshellarg($targetPath)
        );

        // 3) Rsync data from source to destination.
        $rsync = sprintf(
            'rsync -az --delete %s/ root@%s:%s/',
            escapeshellarg($sourcePath),
            escapeshellarg($targetNode->fqdn),
            escapeshellarg($targetPath)
        );
        $this->runLocal($rsync);

        // 4) Update the server and allocations in the database.
        DB::transaction(function () use ($server, $targetNode, $targetAllocation): void {
            $oldAllocationId = (int) $server->allocation_id;

            $server->forceFill([
                'node_id' => $targetNode->id,
                'allocation_id' => $targetAllocation->id,
            ])->save();

            Allocation::query()->where('id', $oldAllocationId)->update(['server_id' => null]);
            Allocation::query()->where('id', $targetAllocation->id)->update(['server_id' => $server->id]);
        });

        // 5) Placeholder sync call.
        $this->syncServerWithNode($server->fresh());

        // 6) Start on destination.
        $this->sendPowerSignal($server->fresh(), 'start');

        Log::info('server-migrator: migration finished', [
            'server_id' => $server->id,
            'target_node_id' => $targetNode->id,
        ]);
    }

    protected function sendPowerSignal(Server $server, string $signal): void
    {
        // TODO: replace with your real panel service or API call.
        Log::info('server-migrator: power signal placeholder', [
            'server_id' => $server->id,
            'signal' => $signal,
        ]);
    }

    protected function syncServerWithNode(Server $server): void
    {
        // TODO: replace with the real sync/rebuild method for your panel version.
        Log::info('server-migrator: sync placeholder', [
            'server_id' => $server->id,
            'node_id' => $server->node_id,
        ]);
    }

    protected function runSsh(Node $node, string $command): void
    {
        $full = sprintf(
            'ssh -o StrictHostKeyChecking=no root@%s %s',
            escapeshellarg($node->fqdn),
            escapeshellarg($command)
        );

        $this->runLocal($full);
    }

    protected function runLocal(string $command): void
    {
        exec($command . ' 2>&1', $output, $code);

        if ($code !== 0) {
            Log::error('server-migrator: command failed', [
                'command' => $command,
                'output' => $output,
                'code' => $code,
            ]);

            throw new RuntimeException('Falha ao executar comando da migracao. Veja os logs do painel.');
        }
    }
}
