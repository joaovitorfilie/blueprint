@extends('layouts.admin')

@section('title')
    Server Migrator
@endsection

@section('content-header')
    <h1>Server Migrator <small>Migrar servidores entre nodes</small></h1>
@endsection

@section('content')
    @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul style="margin-bottom:0;">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Nova migração</h3>
                </div>
                <form method="POST" action="{{ route('admin.server-migrator.migrate') }}">
                    @csrf
                    <div class="box-body">
                        <div class="form-group">
                            <label for="server_id">Servidor</label>
                            <select id="server_id" name="server_id" class="form-control" required>
                                @foreach ($servers as $server)
                                    <option value="{{ $server->id }}">
                                        #{{ $server->id }} - {{ $server->name }} (node {{ $server->node_id }})
                                    </option>
                                @endforeach
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="target_node_id">Node de destino</label>
                            <select id="target_node_id" name="target_node_id" class="form-control" required>
                                @foreach ($nodes as $node)
                                    <option value="{{ $node->id }}">#{{ $node->id }} - {{ $node->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="target_allocation_id">Allocation de destino</label>
                            <select id="target_allocation_id" name="target_allocation_id" class="form-control" required>
                                @foreach ($allocations as $allocation)
                                    <option value="{{ $allocation->id }}">
                                        #{{ $allocation->id }} - node {{ $allocation->node_id }} - {{ $allocation->ip }}:{{ $allocation->port }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    </div>

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Migrar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
