<?php

use Illuminate\Support\Facades\Route;
use ServerMigrator\Http\Controllers\Admin\ServerMigratorController;

Route::middleware(['web', 'auth', 'admin'])
    ->prefix('/admin/tools/server-migrator')
    ->group(function () {
        Route::get('/', [ServerMigratorController::class, 'index'])
            ->name('admin.server-migrator.index');

        Route::post('/migrate', [ServerMigratorController::class, 'migrate'])
            ->name('admin.server-migrator.migrate');
    });
