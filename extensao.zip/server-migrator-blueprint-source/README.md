# Server Migrator for Blueprint

Starter extension for Pterodactyl + Blueprint that migrates a server from one node to another with downtime.

## What is included

- `blueprint.json` and `conf.yml`
- admin routes
- admin page in Blade
- Laravel request validation
- queue job
- migration service using `rsync` and SSH
- installation guide

## Important

This is a **starter/source package**, not a guaranteed one-click production release.
You must adapt it to the exact Blueprint and Panel version you run.

The main placeholders are inside:

- `app/Services/ServerMigrationService.php`

Look for:

- `sendPowerSignal()`
- `syncServerWithNode()`

These methods must be connected to the real power and sync flow in your panel version.

## Main assumptions

- panel can run queue jobs
- passwordless SSH works from the panel host to destination nodes
- `rsync` is installed
- server data lives in `/var/lib/pterodactyl/volumes/<uuid>`
- destination node already has Docker/Wings working

## Safer rollout order

1. install on a staging panel
2. test with a disposable server
3. confirm file copy and allocation switch
4. only then test on production

Read `INSTALL.md` before installing.
